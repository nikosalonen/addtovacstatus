# AddToVacStat.us
Add players from Steam's "Recently played list" to your Vacstat.us list with a single click!
Just generate the private key in your Vacstat.us settings and choose the list where you want to save the players.

*Early release*

Thoughts? Contact vac@torttu.fi or tweet me @nikosalonen
